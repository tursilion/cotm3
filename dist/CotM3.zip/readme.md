19950618

This is a BBS 'door game' that I created in 1995 for CNET BBS, though it was also compiled and ran on Maximus on the PC. I expect it should compile elsewhere as well, although my PC compiler may have been rather non-standard back then.

It should be playable in single-player mode in a command prompt, if you get the data files set up. I've included the data from my old BBS, though personal information, if I found any, should be removed. ;) The zip includes a Windows EXE, for anything else you'll need to get the source to build. I may update it myself someday...

Find more information on setup and usage in HELP.TXT.
